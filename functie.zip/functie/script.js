let voetballer1 = { naam: "Lukaku", leeftijd: 28, team: "Chelsea"};
let voetballer2 = { naam: "Ronaldo", leeftijd: 35, team: "ManUntd"};
let voetballer3 = { naam: "Messi", leeftijd: 34, team: "PSG"};
let lijstobjescten = [voetballer1, voetballer2, voetballer3]

for (let i = 0; i < 5; i++) {
    console.log(i);
}

console.log(lijstobjescten.length);


for (let i = 0; i < lijstobjescten.length; i++) {
    console.log(lijstobjescten[i]);

}