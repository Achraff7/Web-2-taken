// alert gaat een pop-up tonen met een bericht
// hier is het bericht de som van het geal 12 + 13
let getal1 = prompt('geef het eerste getal');
let getal2 = prompt('geef de tweede getal');
console.log
let som = (getal1 * 1) + (getal2 * 1);
alert(som);
//

let isGetalKleinerDanGetal2 = getal1 < getal2;
if (isGetalKleinerDanGetal2) {
    alert('Getal 1 is kleiner dan getal 2');
} else {
    alert('Getal 1 is groter dan getal 2')
}

