var voetballer1 = { naam: "Lukaku", leeftijd: 28, team: "Chelsea"};
var voetballer2 = { naam: "Ronaldo", leeftijd: 35, team: "ManUntd"};
var voetballer3 = { naam: "Messi", leeftijd: 34, team: "PSG"};
var lijstobjescten = [voetballer1, voetballer2, voetballer3]
for (let voetballer of lijstobjescten) {
    console.log(voetballer);
}
